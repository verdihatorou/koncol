let handler = async m => {

let krtu = `web`
m.reply(`
> http://api.tiodevhost.my.id
> http://ytdl.tiodevhost.my.id
`.trim()) 
}
handler.command = /^(web)$/i

module.exports = handler
